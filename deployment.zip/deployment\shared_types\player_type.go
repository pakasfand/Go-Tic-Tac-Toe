package types

type PlayerType int

const (
	PlayerTypeCross PlayerType = iota
	PlayerTypeCircle
)
